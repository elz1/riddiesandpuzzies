		<footer>
		
			<?php //Components\View::render('footer','nav'); ?>
		
		</footer>
		<div id="copyright" class="container">
			<p>©<?php echo date('Y'); ?> Zanswin. All rights reserved. | Design from <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
		</div>
		<?php wp_footer(); ?>
	</body>
</html>