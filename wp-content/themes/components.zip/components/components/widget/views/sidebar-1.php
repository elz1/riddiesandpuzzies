<?php if ( is_active_sidebar( 'sidebar_1' ) ) : ?>
	<div id="sidebar">
		<?php dynamic_sidebar( 'sidebar_1' ); ?>
	</div>
<?php endif; ?>