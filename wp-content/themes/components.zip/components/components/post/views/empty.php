<?php
/**
 * When there is no content to display
 */
?>
<main class="container">
	<div class="row">
		<div class="col-12">

			<h1>Nothing to see here.</h1>
			<p><a href="/">Go Home >></a></p>
			
		</div>
	</div>
</main>