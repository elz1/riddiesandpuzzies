<div class="legal">
	<?php
		wp_nav_menu( array(
			'theme_location' 	=> 'legal',
			'menu_class'     	=> 'legal-menu'
		 ) );
	?>	
</div>
