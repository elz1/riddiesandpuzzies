<div class="footer-nav">
	<?php
		wp_nav_menu( array(
			'theme_location' 	=> 'footer-menu',
			'menu_class'     	=> 'footer-menu'
		 ) );
	?>
</div>