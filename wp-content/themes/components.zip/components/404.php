<?php
/**
 * The 404 Template
 */

get_header(); ?>

		<main class="container">
			<div class="row">
				<div class="col-xs-12">

					<h1>Looks like you're lost</h1>
					<p><a href="/">Go Home >></a></p>
					
				</div>
			</div>
		</main>
	
<?php get_footer(); ?>